Quake 3 Map compiler released by id Software, under GPL v2 licence.

Modified Q3Map2 by ydnar.

Valve map format 220 implementation by XaeroX.

Mac version with Valve map format 220 implementation by Tiny Goose.


BSP Source ".map" files can be either in original Quake format or in new Valve Worldcraft 220 format (allows for more advanced uv projection).
Radiant saves only old format maps, Trenchbroom can save both, Jack only exports in new format.
This version of the compiler can load both formats.
It is required for using Jack, recommended for Trenchbroom, and it loads Radiant maps as well.